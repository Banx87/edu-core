-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table edu_core.admins: ~1 rows (approximately)
INSERT IGNORE INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'Admin', 'admin@gmail.com', NULL, '$2y$12$qygFNE8WJQe4r2diy8IHhep51ylXVIfXq3Yu5TxkNxIg1PW7IxNde', NULL, '2025-04-30 12:48:35', '2025-04-30 12:48:35');

-- Dumping data for table edu_core.cache: ~2 rows (approximately)
INSERT IGNORE INTO `cache` (`key`, `value`, `expiration`) VALUES
	('laravel_cache_gatewaySettings', 'a:21:{s:11:"paypal_mode";s:7:"sandbox";s:15:"paypal_currency";s:3:"USD";s:11:"paypal_rate";s:4:"1.98";s:16:"paypal_client_id";s:80:"AcESFdRsxnGi2bKzeOC64J1xnGsOH0ooeGeOoJU3K9mIaf59JzuauN3UBj6foHOgLx74r8m9LcsDnGlh";s:20:"paypal_client_secret";s:80:"ECCLcmBj43HfqRnCuQ5ClyaaYzJ5dX9eg7W5L3UpbSq-iKRH-n0dTNA4FWqA7rd4tuhrlL_ey2NH92-C";s:13:"paypal_app_id";s:6:"App_id";s:13:"stripe_status";s:8:"inactive";s:15:"stripe_currency";s:3:"USD";s:11:"stripe_rate";s:1:"1";s:22:"stripe_publishable_key";s:107:"pk_test_51ROdu8PnNwEk6GXo4UweaSUDYxlY3qsASnJ72nSjS57YwGEzChvzLZSdZhi24TH6mD6P3wpOtLDoRlM0SvpebrG900AgqELUYd";s:13:"stripe_secret";s:107:"sk_test_51ROdu8PnNwEk6GXou6Nq0sBNK9Ad3YiRP2Dg2qE5q0HJ1sYzIW2Q90LTqxyZyujqnv5L4xtRSff7eCJDXuCTdE5b00OFGBzWVf";s:15:"razorpay_status";s:6:"active";s:17:"razorpay_currency";s:3:"INR";s:13:"razorpay_rate";s:2:"84";s:12:"razorpay_key";s:23:"rzp_test_cvrsy43xvBZfDT";s:15:"razorpay_secret";s:24:"c9Aml4C5vOfSWmZehhlns5df";s:13:"nordea_status";s:8:"inactive";s:15:"nordea_currency";s:3:"AED";s:11:"nordea_rate";s:1:"1";s:16:"nordea_client_id";s:32:"06edbdd1a1b4de14dacf3d3144adc591";s:20:"nordea_client_secret";s:32:"367317d71ff8577866595c16ce530ed1";}', 2063195662),
	('laravel_cache_settings', 'a:6:{s:10:"site_title";s:8:"Edu-Core";s:5:"phone";s:17:"+1 (921) 537-1183";s:8:"location";s:16:"Pennsylvania, US";s:8:"currency";s:3:"USD";s:13:"currency_icon";s:1:"$";s:15:"commission_rate";s:2:"70";}', 2063195662);

-- Dumping data for table edu_core.cache_locks: ~0 rows (approximately)

-- Dumping data for table edu_core.carts: ~2 rows (approximately)
INSERT IGNORE INTO `carts` (`id`, `user_id`, `course_id`, `created_at`, `updated_at`) VALUES
	(44, 1, 29, '2025-05-19 08:46:56', '2025-05-19 08:46:56'),
	(45, 1, 168, '2025-05-19 08:46:57', '2025-05-19 08:46:57');

-- Dumping data for table edu_core.certificate_builders: ~1 rows (approximately)
INSERT IGNORE INTO `certificate_builders` (`id`, `background`, `title`, `subtitle`, `description`, `signature`, `created_at`, `updated_at`) VALUES
	(1, '/uploads/educore_1747841422_682df18e7858e_.jpg', 'PHP Artisan Wizard', 'Now you\'re a wizard', 'This certificate confirms successful completion of the "PHP Artisan Wizard" course. The recipient has demonstrated practical skills in Laravel’s Artisan command-line tool, showing proficiency in managing and automating PHP/Laravel development tasks.', '/uploads/educore_1747842654_682df65ed954c_.png', '2025-05-21 10:54:29', '2025-05-21 12:50:54');

-- Dumping data for table edu_core.certificate_builder_items: ~5 rows (approximately)
INSERT IGNORE INTO `certificate_builder_items` (`id`, `element_id`, `x_position`, `y_position`, `created_at`, `updated_at`) VALUES
	(1, 'signature', '-71', '209', '2025-05-21 13:32:05', '2025-05-21 13:35:12'),
	(2, 'cert_description', '93', '183', '2025-05-21 13:35:14', '2025-05-21 13:48:37'),
	(3, 'cert_title', '-42', '121', '2025-05-21 13:35:16', '2025-05-21 13:48:29'),
	(4, 'cert_subtitle', '-219', '143', '2025-05-21 13:35:18', '2025-05-21 13:48:33'),
	(5, 'cert_signature', '148', '227', '2025-05-21 13:44:41', '2025-05-21 13:48:43');

-- Dumping data for table edu_core.courses: ~17 rows (approximately)
INSERT IGNORE INTO `courses` (`id`, `instructor_id`, `category_id`, `course_type`, `title`, `slug`, `seo_description`, `duration`, `timezone`, `thumbnail`, `preview_video_storage`, `preview_video_source`, `description`, `capacity`, `price`, `discount`, `certificate`, `qna`, `message_for_reviewer`, `is_approved`, `status`, `course_level_id`, `course_language_id`, `created_at`, `updated_at`) VALUES
	(6, 2, 18, 'course', 'Python for Data Analysis: From Zero to Hero', 'python-for-data-analysis-from-zero-to-hero', 'Python for Data Analysis: From Zero to Hero', '250', NULL, '/uploads/educore_1746955287_68206c1709b32_.jpg', 'youtube', 'https://www.youtube.com/watch?v=fWjsdhR3z3c&ab_channel=Indently', 'Master Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.\r\nMaster Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.\r\nMaster Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.\r\nMaster Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.', NULL, 19, 12, 0, 0, NULL, 'approved', 'active', 2, 18, '2025-05-11 04:56:23', '2025-05-19 15:05:07'),
	(29, 2, 18, 'course', 'Digital Marketing Masterclass: SEO, SEM & Social Media', 'digital-marketing-masterclass-seo-sem-social-media', 'Digital Marketing Masterclass: SEO, SEM & Social Media', '10', NULL, '/uploads/educore_1746955351_68206c1a2fbaa_.jpg', 'youtube', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'Learn the core strategies in digital marketing: search engine optimization (SEO), search engine marketing (SEM), content marketing, and social media advertising. Optimize campaigns and measure ROI.', 93, 249, 20, 1, 1, 'I have put a lot of effort into creating a comprehensive digital marketing course. I would appreciate your feedback on how I can improve it.', 'approved', 'active', 1, 18, '2025-05-11 11:37:05', '2025-05-11 11:37:05'),
	(88, 2, 18, 'course', 'Python for Data Analysis: From Zero to Hero', 'python-for-data-analysis-from-zero-to-hero', 'Python for Data Analysis: From Zero to Hero', '350', NULL, '/uploads/educore_1746955287_68206c1709b32_.jpg', 'youtube', 'https://www.youtube.com/watch?v=4Y6t7Dv4qa0', 'Master Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.', 33, 59, 30, 1, 1, 'Please review my course. I have put a lot of effort into it and would appreciate your valuable feedback.', 'approved', 'active', 1, 18, '2025-05-11 11:37:05', '2025-05-11 11:37:05'),
	(150, 2, 18, 'course', 'Digital Marketing Masterclass: SEO, SEM & Social Media', 'digital-marketing-masterclass-seo-sem-social-media', 'Digital Marketing Masterclass: SEO, SEM & Social Media', '10', NULL, '/uploads/educore_1746955351_68206c1a2fbaa_.jpg', 'youtube', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'Learn the core strategies in digital marketing: search engine optimization (SEO), search engine marketing (SEM), content marketing, and social media advertising. Optimize campaigns and measure ROI.', 71, 249, 20, 1, 1, 'I have put a lot of effort into creating a comprehensive digital marketing course. I would appreciate your feedback on how I can improve it.', 'approved', 'active', 1, 18, '2025-05-11 11:36:28', '2025-05-11 11:36:28'),
	(168, 2, 18, 'course', 'UX Design Essentials: Crafting User-Centered Experiences', 'ux-design-essentials-crafting-user-centered-experiences', 'UX Design Essentials: Crafting User-Centered Experiences', '6', NULL, '/uploads/educore_1746955321_68206c18d49a2_.jpg', 'youtube', 'https://www.youtube.com/watch?v=VhJXWv4Qc1c', 'Dive into the fundamentals of user experience (UX) design: user research, wireframing, prototyping, and usability testing. Build your portfolio with real-world design challenges.', 72, 149, 100, 1, 1, 'I am excited to share my UX Design Essentials course with you. I believe it will be a valuable resource for designers looking to improve their skills.', 'approved', 'active', 1, 18, '2025-05-11 11:36:28', '2025-05-11 11:36:28'),
	(170, 2, 18, 'course', 'Python for Data Analysis: From Zero to Hero', 'python-for-data-analysis-from-zero-to-hero', 'Python for Data Analysis: From Zero to Hero', '350', NULL, '/uploads/educore_1746955287_68206c1709b32_.jpg', 'youtube', 'https://www.youtube.com/watch?v=4Y6t7Dv4qa0', 'Master Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.', 96, 59, 30, 1, 1, 'Please review my course. I have put a lot of effort into it and would appreciate your valuable feedback.', 'approved', 'active', 1, 18, '2025-05-11 11:36:28', '2025-05-11 11:36:28'),
	(240, 2, 18, 'course', 'UX Design Essentials: Crafting User-Centered Experiences', 'ux-design-essentials-crafting-user-centered-experiences', 'UX Design Essentials: Crafting User-Centered Experiences', '6', NULL, '/uploads/educore_1746955321_68206c18d49a2_.jpg', 'youtube', 'https://www.youtube.com/watch?v=VhJXWv4Qc1c', 'Dive into the fundamentals of user experience (UX) design: user research, wireframing, prototyping, and usability testing. Build your portfolio with real-world design challenges.', 95, 149, 100, 1, 1, 'I am excited to share my UX Design Essentials course with you. I believe it will be a valuable resource for designers looking to improve their skills.', 'approved', 'active', 1, 18, '2025-05-11 11:37:05', '2025-05-11 11:37:05'),
	(288, 2, 18, 'course', 'Productivity & Time Management: Achieve Your Goals', 'productivity-time-management-achieve-your-goals', 'Productivity & Time Management: Achieve Your Goals', '4', NULL, '/uploads/educore_1746955484_68206c1f1ca2b_.jpg', 'youtube', 'https://www.youtube.com/watch?v=7Yj8yf7YjZ0', 'Learn evidence-based techniques to boost focus, manage tasks, and eliminate procrastination. Implement systems like GTD, Pomodoro, and Eisenhower Matrix.', 77, 99, 20, 1, 1, 'Please review my course.', 'approved', 'active', 1, 18, '2025-05-11 11:37:23', '2025-05-11 11:37:23'),
	(407, 2, 18, 'course', 'Digital Marketing Masterclass: SEO, SEM & Social Media', 'digital-marketing-masterclass-seo-sem-social-media', 'Digital Marketing Masterclass: SEO, SEM & Social Media', '10', NULL, '/uploads/educore_1746955351_68206c1a2fbaa_.jpg', 'youtube', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'Learn the core strategies in digital marketing: search engine optimization (SEO), search engine marketing (SEM), content marketing, and social media advertising. Optimize campaigns and measure ROI.', 35, 249, 20, 1, 1, 'I have put a lot of effort into creating a comprehensive digital marketing course. I would appreciate your feedback on how I can improve it.', 'approved', 'active', 1, 18, '2025-05-11 11:37:23', '2025-05-11 11:37:23'),
	(414, 2, 18, 'course', 'Full-Stack Web Development with JavaScript', 'full-stack-web-development-with-javascript', 'Full-Stack Web Development with JavaScript', '12', NULL, '/uploads/educore_1746955376_68206c1c9f2e8_.jpg', 'youtube', 'https://www.youtube.com/watch?v=VhJXWv4Qc1c', 'Become a full-stack developer by learning front-end (React) and back-end (Node.js, Express, MongoDB). Build and deploy production-ready web applications.', 74, 349, 0, 1, 1, 'I am excited to share my full-stack web development course with you. I believe it will be a valuable resource for developers looking to improve their skills.', 'approved', 'active', 1, 18, '2025-05-11 11:37:05', '2025-05-11 11:37:05'),
	(506, 2, 18, 'course', 'Python for Data Analysis: From Zero to Hero', 'python-for-data-analysis-from-zero-to-hero', 'Python for Data Analysis: From Zero to Hero', '350', NULL, '/uploads/educore_1746955287_68206c1709b32_.jpg', 'youtube', 'https://www.youtube.com/watch?v=4Y6t7Dv4qa0', 'Master Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.', 80, 59, 30, 1, 1, 'Please review my course. I have put a lot of effort into it and would appreciate your valuable feedback.', 'approved', 'active', 1, 18, '2025-05-11 11:35:20', '2025-05-11 11:35:20'),
	(533, 2, 18, 'course', 'Full-Stack Web Development with JavaScript', 'full-stack-web-development-with-javascript', 'Full-Stack Web Development with JavaScript', '12', NULL, '/uploads/educore_1746955376_68206c1c9f2e8_.jpg', 'youtube', 'https://www.youtube.com/watch?v=VhJXWv4Qc1c', 'Become a full-stack developer by learning front-end (React) and back-end (Node.js, Express, MongoDB). Build and deploy production-ready web applications.', 88, 349, 0, 1, 1, 'I am excited to share my full-stack web development course with you. I believe it will be a valuable resource for developers looking to improve their skills.', 'approved', 'active', 1, 18, '2025-05-11 11:37:23', '2025-05-11 11:37:23'),
	(546, 2, 18, 'course', 'Conversational Spanish: Beginner to Intermediate', 'conversational-spanish-beginner-to-intermediate', 'Conversational Spanish: Beginner to Intermediate', '5', NULL, '/uploads/educore_1746955384_68206c1f1c82b_.jpg', 'youtube', 'https://www.youtube.com/watch?v=yYc7F3yf6nU', 'Build practical Spanish conversation skills for travel, work, and everyday life. Focus on speaking, listening, and cultural nuances through interactive dialogues.', 67, 129, 0, 1, 1, 'Please review my course. I am excited to share it with you and would appreciate your feedback.', 'approved', 'active', 1, 18, '2025-05-11 11:37:23', '2025-05-11 11:37:23'),
	(659, 2, 18, 'course', 'Python for Data Analysis: From Zero to Hero', 'python-for-data-analysis-from-zero-to-hero', 'Python for Data Analysis: From Zero to Hero', '350', NULL, '/uploads/educore_1746955287_68206c1709b32_.jpg', 'youtube', 'https://www.youtube.com/watch?v=4Y6t7Dv4qa0', 'Master Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.', 55, 59, 30, 1, 1, 'Please review my course. I have put a lot of effort into it and would appreciate your valuable feedback.', 'approved', 'active', 1, 18, '2025-05-11 11:33:01', '2025-05-11 11:33:01'),
	(721, 2, 18, 'course', 'UX Design Essentials: Crafting User-Centered Experiences', 'ux-design-essentials-crafting-user-centered-experiences', 'UX Design Essentials: Crafting User-Centered Experiences', '6', NULL, '/uploads/educore_1746955321_68206c18d49a2_.jpg', 'youtube', 'https://www.youtube.com/watch?v=VhJXWv4Qc1c', 'Dive into the fundamentals of user experience (UX) design: user research, wireframing, prototyping, and usability testing. Build your portfolio with real-world design challenges.', 40, 149, 100, 1, 1, 'I am excited to share my UX Design Essentials course with you. I believe it will be a valuable resource for designers looking to improve their skills.', 'approved', 'active', 1, 18, '2025-05-11 11:37:23', '2025-05-11 11:37:23'),
	(878, 2, 18, 'course', 'Python for Data Analysis: From Zero to Hero', 'python-for-data-analysis-from-zero-to-hero', 'Python for Data Analysis: From Zero to Hero', '350', NULL, '/uploads/educore_1746955287_68206c1709b32_.jpg', 'youtube', 'https://www.youtube.com/watch?v=4Y6t7Dv4qa0', 'Master Python programming with a focus on real-world data analysis. Learn to manipulate datasets, perform statistical analysis, and create insightful visualizations using libraries like pandas, NumPy, and Matplotlib.', 61, 59, 30, 0, 0, 'Please review my course. I have put a lot of effort into it and would appreciate your valuable feedback.', 'approved', 'active', 1, 18, '2025-05-11 11:37:23', '2025-05-20 04:58:48'),
	(916, 2, 18, 'course', 'Full-Stack Web Development with JavaScript', 'full-stack-web-development-with-javascript', 'Full-Stack Web Development with JavaScript', '12', NULL, '/uploads/educore_1746955376_68206c1c9f2e8_.jpg', 'youtube', 'https://www.youtube.com/watch?v=VhJXWv4Qc1c', 'Become a full-stack developer by learning front-end (React) and back-end (Node.js, Express, MongoDB). Build and deploy production-ready web applications.', 34, 349, 0, 1, 1, 'I am excited to share my full-stack web development course with you. I believe it will be a valuable resource for developers looking to improve their skills.', 'approved', 'active', 1, 18, '2025-05-11 11:36:28', '2025-05-11 11:36:28');

-- Dumping data for table edu_core.course_categories: ~6 rows (approximately)
INSERT IGNORE INTO `course_categories` (`id`, `name`, `image`, `icon`, `slug`, `description`, `parent_id`, `set_trending`, `status`, `created_at`, `updated_at`) VALUES
	(7, 'Web Design', '/uploads/educore_1746186216_6814afe8097c6_.png', 'ti ti-link', 'web-design', NULL, NULL, 1, 0, '2025-05-01 11:12:58', '2025-05-02 08:44:00'),
	(8, 'Graphic Design', '/uploads/educore_1746182444_6814a12c97140_.png', 'ti ti-olympics', 'graphic-design', NULL, NULL, 1, 1, '2025-05-01 11:39:24', '2025-05-02 11:44:40'),
	(9, 'Reading', '/uploads/educore_1746186301_6814b03d9f1b7_.png', 'ti ti-book', 'reading', NULL, NULL, 1, 1, '2025-05-02 06:46:29', '2025-05-02 08:45:01'),
	(10, 'Artificial Intelligence', '/uploads/educore_1746182580_6814a1b48bdb1_.png', 'ti ti-pill', 'artificial-intelligence', NULL, NULL, 1, 0, '2025-05-02 07:20:31', '2025-05-02 08:44:33'),
	(17, 'HTML', '/uploads/educore_1746196738_6814d9024ece5_.png', 'ti ti-html', 'html', NULL, 7, 0, 1, '2025-05-02 11:38:58', '2025-05-02 11:38:58'),
	(18, 'Figma Design', NULL, 'ti ti-brand-figma', 'figma-design', NULL, 8, 1, 0, '2025-05-02 11:45:02', '2025-05-02 11:45:02');

-- Dumping data for table edu_core.course_chapters: ~10 rows (approximately)
INSERT IGNORE INTO `course_chapters` (`id`, `title`, `instructor_id`, `course_id`, `order`, `status`, `created_at`, `updated_at`) VALUES
	(9, 'Chapter 1: Python Fundamentals', 2, 6, 1, 1, '2025-05-11 04:59:36', '2025-05-11 04:59:36'),
	(10, 'Chapter 2: Efficient Data Ingestion', 2, 6, 2, 1, '2025-05-11 05:10:39', '2025-05-11 05:10:39'),
	(12, 'Chapter 3: Data Cleaning & Wrangling', 2, 6, 3, 1, '2025-05-11 10:19:28', '2025-05-11 10:19:28'),
	(13, 'Chapter 4: Exploratory Data Analysis (EDA)', 2, 6, 4, 1, '2025-05-11 10:19:36', '2025-05-11 10:19:36'),
	(14, 'Chapter 5: Data Visualization', 2, 6, 5, 1, '2025-05-11 10:19:43', '2025-05-11 10:19:43'),
	(15, 'Chapter 6: Numerical Computing with NumPy', 2, 6, 6, 1, '2025-05-11 10:19:50', '2025-05-11 10:19:50'),
	(16, 'Chapter 7: Introduction to Statistics in Python', 2, 6, 7, 1, '2025-05-11 10:19:56', '2025-05-11 10:19:56'),
	(17, 'Chapter 8: Final Capstone Project', 2, 6, 8, 1, '2025-05-11 10:20:06', '2025-05-11 10:20:06'),
	(26, 'Hevireissu', 2, 878, 1, 1, '2025-05-20 04:58:56', '2025-05-20 04:58:56'),
	(28, 'Pepé', 2, 878, 3, 1, '2025-05-20 04:59:24', '2025-05-20 04:59:24');

-- Dumping data for table edu_core.course_chapter_lessons: ~31 rows (approximately)
INSERT IGNORE INTO `course_chapter_lessons` (`id`, `title`, `slug`, `description`, `instructor_id`, `course_id`, `chapter_id`, `file_path`, `storage`, `volume`, `duration`, `file_type`, `downloadable`, `order`, `is_preview`, `status`, `lesson_type`, `created_at`, `updated_at`) VALUES
	(5, 'Installing Your Toolkit', 'installing-your-toolkit', 'Setting up Anaconda or Miniconda\nCreating virtual environments\nManaging packages with pip and conda', 2, 6, 9, 'https://www.youtube.com/watch?v=rIfdg_Ot-LI&ab_channel=Fireship', 'youtube', NULL, '10', 'video', 0, 1, 1, 1, 'lesson', '2025-05-11 05:01:11', '2025-05-11 05:01:11'),
	(6, '(VIMEO) Python Basics Refresher', 'vimeo-python-basics-refresher', 'Variables, data types, and basic operations\r\nControl flow: if statements, loops\r\nWriting and calling functions', 2, 6, 9, 'https://vimeo.com/1007718657', 'vimeo', NULL, '8', 'video', 0, 2, 1, 1, 'lesson', '2025-05-11 05:02:23', '2025-05-19 13:19:09'),
	(7, 'Working with Data Structures', 'working-with-data-structures', 'Lists, tuples, sets, dictionaries\nList/dict comprehensions\nWhen to use each structure', 2, 6, 9, 'https://youtube.com', 'youtube', NULL, '17', 'video', 0, 3, 1, 1, 'lesson', '2025-05-11 05:03:11', '2025-05-11 05:03:11'),
	(8, 'Modules and Packages (Audio file Test)', 'modules-and-packages-audio-file-test', 'Standard library modules you need\r\nImport syntax and best practices\r\nCreating your own modules', 2, 6, 9, 'https://www.youtube.com/watch?v=qzl2t2p7AYc', 'youtube', NULL, '25', 'video', 0, 4, 0, 1, 'lesson', '2025-05-11 05:03:38', '2025-05-21 08:25:11'),
	(9, 'Reading CSVs with pandas (vimeo)', 'reading-csvs-with-pandas-vimeo', 'Using pd.read_csv() options\r\nHandling delimiters, encodings, large files', 2, 6, 10, 'https://vimeo.com/1081910456', 'vimeo', NULL, '14', 'video', 0, 1, 0, 1, 'lesson', '2025-05-11 05:11:07', '2025-05-19 12:55:54'),
	(10, 'Excel, JSON & SQL Sources', 'excel-json-sql-sources', 'pd.read_excel(), pd.read_json()\nConnecting to a SQLite/MySQL database', 2, 6, 10, 'https://youtube.com', 'youtube', NULL, '5', 'video', 0, 2, 0, 1, 'lesson', '2025-05-11 05:11:32', '2025-05-11 05:11:32'),
	(11, 'Web Scraping for Data', 'web-scraping-for-data', 'Using requests & BeautifulSoup\nParsing HTML tables', 2, 6, 10, 'https://youtube.com', 'youtube', NULL, '20', 'video', 0, 3, 0, 1, 'lesson', '2025-05-11 05:11:56', '2025-05-11 05:11:56'),
	(12, 'APIs and JSON into DataFrames', 'apis-and-json-into-dataframes', 'Consuming RESTful APIs\nNormalizing nested JSON into tabular form', 2, 6, 10, 'https://youtube.com', 'youtube', NULL, '12', 'video', 0, 4, 0, 1, 'lesson', '2025-05-11 05:12:25', '2025-05-11 05:12:25'),
	(14, 'Matplotlib Fundamentals', 'matplotlib-fundamentals', 'Creating line, bar, and scatter plots. Customizing axes, titles, and legends.', 2, 6, 13, 'https://youtube.com', 'youtube', NULL, '20', 'video', 0, 1, 0, 1, 'lesson', '2025-05-11 05:13:00', '2025-05-11 05:13:00'),
	(15, 'Visualizing DataFrames Directly', 'visualizing-dataframes-directly', 'Pandas’ built-in .plot() interface. Quick plots vs. full customization.', 2, 6, 14, 'https://youtube.com', 'youtube', NULL, '18', 'video', 0, 2, 0, 1, 'lesson', '2025-05-11 05:13:30', '2025-05-11 05:13:30'),
	(16, 'Advanced Plots: Histograms, Boxplots & KDE', 'advanced-plots-histograms-boxplots-kde', 'Distribution visualizations. Comparing groups side-by-side.', 2, 6, 14, 'https://youtube.com', 'youtube', NULL, '25', 'video', 0, 3, 0, 1, 'lesson', '2025-05-11 05:14:00', '2025-05-11 05:14:00'),
	(17, 'Time Series Plotting', 'time-series-plotting', 'Plotting date-indexed data. Rolling statistics and overlays.', 2, 6, 14, 'https://youtube.com', 'youtube', NULL, '22', 'video', 0, 4, 0, 1, 'lesson', '2025-05-11 05:14:30', '2025-05-11 05:14:30'),
	(18, 'Seaborn Overview (Optional)', 'seaborn-overview-optional', 'Integrating Seaborn for attractive defaults. Pairplots and jointplots.', 2, 6, 14, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 5, 0, 1, 'lesson', '2025-05-11 05:15:00', '2025-05-11 05:15:00'),
	(19, 'ndarray Basics', 'ndarray-basics', 'Creating arrays, indexing, slicing', 2, 6, 15, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 1, 0, 1, 'lesson', '2025-05-11 05:15:30', '2025-05-11 05:15:30'),
	(20, 'Broadcasting rules', 'broadcasting-rules', '', 2, 6, 15, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 2, 0, 1, 'lesson', '2025-05-11 05:16:00', '2025-05-11 05:16:00'),
	(21, 'Vectorized Operations', 'vectorized-operations', 'Arithmetic, comparison, boolean masking', 2, 6, 15, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 3, 0, 1, 'lesson', '2025-05-11 05:16:30', '2025-05-11 05:16:30'),
	(22, 'Speed benefits over pure Python loops', 'speed-benefits-over-pure-python-loops', '', 2, 6, 15, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 4, 0, 1, 'lesson', '2025-05-11 05:17:00', '2025-05-11 05:17:00'),
	(23, 'Linear Algebra & Statistics', 'linear-algebra-statistics', 'Dot products, matrix multiplication', 2, 6, 15, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 5, 0, 1, 'lesson', '2025-05-11 05:17:30', '2025-05-11 05:17:30'),
	(24, 'Mean, median, standard deviation', 'mean-median-standard-deviation', '', 2, 6, 15, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 6, 0, 1, 'lesson', '2025-05-11 05:18:00', '2025-05-11 05:18:00'),
	(25, 'Integrating NumPy with pandas', 'integrating-numpy-with-pandas', 'Converting between DataFrames and ndarrays', 2, 6, 15, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 7, 0, 1, 'lesson', '2025-05-11 05:18:30', '2025-05-11 05:18:30'),
	(26, 'Probability Distributions', 'probability-distributions', 'Normal, binomial, Poisson in scipy.stats', 2, 6, 16, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 1, 0, 1, 'lesson', '2025-05-11 05:19:00', '2025-05-11 05:19:00'),
	(27, 'Sampling and Random Variates', 'sampling-and-random-variates', '', 2, 6, 16, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 2, 0, 1, 'lesson', '2025-05-11 05:19:30', '2025-05-11 05:19:30'),
	(28, 'Hypothesis Testing', 'hypothesis-testing', 'T-tests, chi-square tests', 2, 6, 16, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 3, 0, 1, 'lesson', '2025-05-11 05:20:00', '2025-05-11 05:20:00'),
	(29, 'Interpreting p-values', 'interpreting-p-values', '', 2, 6, 16, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 4, 0, 1, 'lesson', '2025-05-11 05:20:30', '2025-05-11 05:20:30'),
	(30, 'Regression Basics', 'regression-basics', 'Simple linear regression with statsmodels', 2, 6, 16, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 5, 0, 1, 'lesson', '2025-05-11 05:21:00', '2025-05-11 05:21:00'),
	(31, 'Assessing Model Fit', 'assessing-model-fit', 'R², residuals', 2, 6, 16, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 6, 0, 1, 'lesson', '2025-05-11 05:21:30', '2025-05-11 05:21:30'),
	(32, 'Putting It All Together', 'putting-it-all-together', 'Small case study: A/B test analysis', 2, 6, 16, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 7, 0, 1, 'lesson', '2025-05-11 05:22:00', '2025-05-11 05:22:00'),
	(33, 'Final Capstone Project Project Proposal & Dataset Selection', 'final-capstone-project-project-proposal-dataset-selection', 'Defining a clear question or hypothesis, Sourcing and justifying chosen data', 2, 6, 17, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 1, 0, 1, 'lesson', '2025-05-11 05:22:30', '2025-05-11 05:22:30'),
	(34, 'End-to-End Pipeline', 'end-to-end-pipeline', 'Data ingestion → cleaning → EDA → visualization', 2, 6, 17, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 2, 0, 1, 'lesson', '2025-05-11 05:23:00', '2025-05-11 05:23:00'),
	(35, 'Statistical Insights & Modeling', 'statistical-insights-modeling', 'Applying simple models or statistical tests, Highlighting key findings', 2, 6, 17, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 3, 0, 1, 'lesson', '2025-05-11 05:23:30', '2025-05-11 05:23:30'),
	(36, 'Reporting & Presentation', 'reporting-presentation', 'Creating a Jupyter-based report, Best practices for clear, reproducible narratives', 2, 6, 17, 'https://youtube.com', 'youtube', NULL, '30', 'video', 0, 4, 0, 1, 'lesson', '2025-05-11 05:24:00', '2025-05-11 05:24:00');

-- Dumping data for table edu_core.course_languages: ~7 rows (approximately)
INSERT IGNORE INTO `course_languages` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
	(18, 'English', 'english', '2025-05-01 09:17:51', '2025-05-01 09:17:51'),
	(19, 'Italian', 'italian', '2025-05-01 09:17:55', '2025-05-01 09:17:55'),
	(20, 'German', 'german', '2025-05-01 09:17:59', '2025-05-01 09:17:59'),
	(21, 'Swedish', 'swedish', '2025-05-01 09:18:04', '2025-05-01 09:18:04'),
	(22, 'Finnish', 'finnish', '2025-05-01 09:18:08', '2025-05-01 09:18:08'),
	(23, 'French', 'french', '2025-05-01 09:18:13', '2025-05-01 09:18:13'),
	(24, 'Hebrew', 'hebrew', '2025-05-04 04:45:15', '2025-05-04 04:45:15');

-- Dumping data for table edu_core.course_levels: ~3 rows (approximately)
INSERT IGNORE INTO `course_levels` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
	(1, 'Intermediate', 'intermediate', '2025-05-01 05:14:11', '2025-05-01 05:15:19'),
	(2, 'Beginner', 'beginner', '2025-05-01 05:15:25', '2025-05-01 05:15:25'),
	(3, 'Expert', 'expert', '2025-05-01 05:15:47', '2025-05-01 05:15:47');

-- Dumping data for table edu_core.enrollments: ~22 rows (approximately)
INSERT IGNORE INTO `enrollments` (`id`, `user_id`, `course_id`, `instructor_id`, `have_access`, `created_at`, `updated_at`) VALUES
	(1, 1, 88, 2, 1, '2025-05-13 09:44:23', '2025-05-13 09:44:23'),
	(2, 1, 6, 2, 1, '2025-05-13 09:44:23', '2025-05-13 09:44:23'),
	(3, 1, 168, 2, 1, '2025-05-13 09:44:23', '2025-05-13 09:44:23'),
	(4, 1, 88, 2, 1, '2025-05-13 10:15:35', '2025-05-13 10:15:35'),
	(5, 1, 88, 2, 1, '2025-05-13 10:19:42', '2025-05-13 10:19:42'),
	(6, 1, 168, 2, 1, '2025-05-13 10:19:42', '2025-05-13 10:19:42'),
	(7, 1, 6, 2, 1, '2025-05-13 10:21:18', '2025-05-13 10:21:18'),
	(8, 1, 88, 2, 1, '2025-05-13 10:21:18', '2025-05-13 10:21:18'),
	(9, 1, 168, 2, 1, '2025-05-14 05:32:21', '2025-05-14 05:32:21'),
	(10, 1, 170, 2, 1, '2025-05-14 05:32:21', '2025-05-14 05:32:21'),
	(11, 1, 29, 2, 1, '2025-05-14 10:31:52', '2025-05-14 10:31:52'),
	(12, 1, 150, 2, 1, '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(13, 1, 240, 2, 1, '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(14, 1, 88, 2, 1, '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(15, 1, 288, 2, 1, '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(16, 1, 240, 2, 1, '2025-05-17 04:58:07', '2025-05-17 04:58:07'),
	(17, 1, 168, 2, 1, '2025-05-17 04:58:55', '2025-05-17 04:58:55'),
	(18, 1, 168, 2, 1, '2025-05-17 05:03:44', '2025-05-17 05:03:44'),
	(19, 1, 168, 2, 1, '2025-05-17 05:06:24', '2025-05-17 05:06:24'),
	(20, 1, 168, 2, 1, '2025-05-17 05:08:10', '2025-05-17 05:08:10'),
	(21, 1, 240, 2, 1, '2025-05-17 05:08:10', '2025-05-17 05:08:10'),
	(22, 1, 29, 2, 1, '2025-05-17 05:12:53', '2025-05-17 05:12:53');

-- Dumping data for table edu_core.failed_jobs: ~0 rows (approximately)

-- Dumping data for table edu_core.instructor_payout_information: ~1 rows (approximately)
INSERT IGNORE INTO `instructor_payout_information` (`id`, `instructor_id`, `payout_gateway`, `information`, `created_at`, `updated_at`) VALUES
	(1, 2, 'Razorpay', 'This is now mass assignable? This is an uypdate. Don\'t do a new one.', '2025-05-17 15:26:16', '2025-05-17 15:58:01');

-- Dumping data for table edu_core.jobs: ~3 rows (approximately)
INSERT IGNORE INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
	(1, 'default', '{"uuid":"db848a36-ce07-41f5-9ca4-b239807b4e50","displayName":"App\\\\Mail\\\\InstructorRequestRejectedMail","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Mail\\\\SendQueuedMailable","command":"O:34:\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\":15:{s:8:\\"mailable\\";O:38:\\"App\\\\Mail\\\\InstructorRequestRejectedMail\\":2:{s:2:\\"to\\";a:1:{i:0;a:2:{s:4:\\"name\\";N;s:7:\\"address\\";s:25:\\"michael.scott@testing.com\\";}}s:6:\\"mailer\\";s:4:\\"smtp\\";}s:5:\\"tries\\";N;s:7:\\"timeout\\";N;s:13:\\"maxExceptions\\";N;s:17:\\"shouldBeEncrypted\\";b:0;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:5:\\"delay\\";N;s:11:\\"afterCommit\\";N;s:10:\\"middleware\\";a:0:{}s:7:\\"chained\\";a:0:{}s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:19:\\"chainCatchCallbacks\\";N;s:3:\\"job\\";N;}"}}', 0, NULL, 1746032283, 1746032283),
	(2, 'default', '{"uuid":"2413a06f-ee8e-408a-aa5d-ba57f7b09183","displayName":"App\\\\Mail\\\\InstructorRequestApprovedMail","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Mail\\\\SendQueuedMailable","command":"O:34:\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\":15:{s:8:\\"mailable\\";O:38:\\"App\\\\Mail\\\\InstructorRequestApprovedMail\\":2:{s:2:\\"to\\";a:1:{i:0;a:2:{s:4:\\"name\\";N;s:7:\\"address\\";s:25:\\"michael.scott@testing.com\\";}}s:6:\\"mailer\\";s:4:\\"smtp\\";}s:5:\\"tries\\";N;s:7:\\"timeout\\";N;s:13:\\"maxExceptions\\";N;s:17:\\"shouldBeEncrypted\\";b:0;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:5:\\"delay\\";N;s:11:\\"afterCommit\\";N;s:10:\\"middleware\\";a:0:{}s:7:\\"chained\\";a:0:{}s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:19:\\"chainCatchCallbacks\\";N;s:3:\\"job\\";N;}"}}', 0, NULL, 1746196361, 1746196361),
	(3, 'default', '{"uuid":"f8934b8c-13af-4fd7-b2a1-63b7c36ccb7c","displayName":"App\\\\Mail\\\\InstructorRequestRejectedMail","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Mail\\\\SendQueuedMailable","command":"O:34:\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\":15:{s:8:\\"mailable\\";O:38:\\"App\\\\Mail\\\\InstructorRequestRejectedMail\\":2:{s:2:\\"to\\";a:1:{i:0;a:2:{s:4:\\"name\\";N;s:7:\\"address\\";s:20:\\"instructor@gmail.com\\";}}s:6:\\"mailer\\";s:4:\\"smtp\\";}s:5:\\"tries\\";N;s:7:\\"timeout\\";N;s:13:\\"maxExceptions\\";N;s:17:\\"shouldBeEncrypted\\";b:0;s:10:\\"connection\\";N;s:5:\\"queue\\";N;s:5:\\"delay\\";N;s:11:\\"afterCommit\\";N;s:10:\\"middleware\\";a:0:{}s:7:\\"chained\\";a:0:{}s:15:\\"chainConnection\\";N;s:10:\\"chainQueue\\";N;s:19:\\"chainCatchCallbacks\\";N;s:3:\\"job\\";N;}"}}', 0, NULL, 1746196393, 1746196393);

-- Dumping data for table edu_core.job_batches: ~0 rows (approximately)

-- Dumping data for table edu_core.migrations: ~24 rows (approximately)
INSERT IGNORE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(13, '0001_01_01_000000_create_users_table', 1),
	(14, '0001_01_01_000001_create_cache_table', 1),
	(15, '0001_01_01_000002_create_jobs_table', 1),
	(16, '2025_04_23_115421_create_admins_table', 1),
	(17, '2025_04_25_083730_create_orders_table', 1),
	(18, '2025_04_30_094859_create_course_languages_table', 1),
	(19, '2025_04_30_094869_create_course_levels_table', 2),
	(21, '2025_05_01_092603_create_course_categories_table', 3),
	(25, '2025_05_03_093952_create_courses_table', 4),
	(26, '2025_05_05_122231_create_course_chapters_table', 4),
	(27, '2025_05_06_071846_create_course_chapter_lessons_table', 4),
	(28, '2025_05_12_071119_create_carts_table', 5),
	(33, '2025_05_13_094944_create_orders_table', 6),
	(34, '2025_05_13_095510_create_order_items_table', 6),
	(35, '2025_05_13_123330_create_enrollments_table', 7),
	(36, '2025_05_13_134023_create_payment_settings_table', 8),
	(37, '2025_05_16_114508_create_settings_table', 9),
	(38, '2025_05_17_085652_create_payout_gateways_table', 10),
	(41, '2025_05_17_174701_create_instructor_payout_information_table', 11),
	(43, '2025_05_18_075959_create_withdrawals_table', 12),
	(45, '2025_05_20_091404_create_watch_histories_table', 13),
	(49, '2025_05_21_121640_create_certificate_builder_table', 14),
	(50, '2025_05_21_121640_create_certificate_builders_table', 15),
	(51, '2025_05_21_161509_create_certificate_builder_items_table', 16);

-- Dumping data for table edu_core.orders: ~18 rows (approximately)
INSERT IGNORE INTO `orders` (`id`, `invoice_id`, `buyer_id`, `status`, `total_amount`, `paid_amount`, `currency`, `has_coupon`, `coupon_code`, `coupon_amount`, `transaction_id`, `payment_method`, `created_at`, `updated_at`) VALUES
	(1, '682322020c003', 1, 'completed', 521, 521, 'USD', 0, NULL, NULL, '3E026957HG8637507', 'paypal', '2025-05-13 07:42:10', '2025-05-13 07:42:10'),
	(2, '682324488dca3', 1, 'completed', 142, 142, 'USD', 0, NULL, NULL, '88P715660A931130C', 'paypal', '2025-05-13 07:51:52', '2025-05-13 07:51:52'),
	(3, '682324a03ca7d', 1, 'completed', 142, 142, 'USD', 0, NULL, NULL, '4XE98126BJ489744W', 'paypal', '2025-05-13 07:53:20', '2025-05-13 07:53:20'),
	(4, '68233dfa4a376', 1, 'completed', 142, 142, 'USD', 0, NULL, NULL, '4SL70330J19567102', 'paypal', '2025-05-13 09:41:30', '2025-05-13 09:41:30'),
	(5, '68233ea7eda3f', 1, 'completed', 142, 142, 'USD', 0, NULL, NULL, '0LJ65152HW680044E', 'paypal', '2025-05-13 09:44:23', '2025-05-13 09:44:23'),
	(6, '6823459edfb51', 1, 'completed', 130, 130, 'USD', 0, NULL, NULL, '4HA70969KN792405X', 'paypal', '2025-05-13 10:14:06', '2025-05-13 10:14:06'),
	(7, '682345f7a386e', 1, 'completed', 130, 130, 'USD', 0, NULL, NULL, '0D864452WN7913823', 'paypal', '2025-05-13 10:15:35', '2025-05-13 10:15:35'),
	(8, '682346eeb1af5', 1, 'completed', 130, 130, 'USD', 0, NULL, NULL, '62E43894F2594611U', 'paypal', '2025-05-13 10:19:42', '2025-05-13 10:19:42'),
	(9, '6823474e11d5a', 1, 'completed', 42, 42, 'USD', 0, NULL, NULL, '2DU85922P86554015', 'paypal', '2025-05-13 10:21:18', '2025-05-13 10:21:18'),
	(10, '682455150c782', 1, 'completed', 130, 130, 'USD', 0, NULL, NULL, '54H41582U1562673J', 'paypal', '2025-05-14 05:32:21', '2025-05-14 05:32:21'),
	(11, '68249b48a9a78', 1, 'completed', 20, 20, 'usd', 0, NULL, NULL, 'pi_3ROfPXPnNwEk6GXo1BV40UUQ', 'stripe', '2025-05-14 10:31:52', '2025-05-14 10:31:52'),
	(12, '6828413d22fe0', 1, 'completed', 170, 336.6, 'USD', 0, NULL, NULL, '2S325766DC483370V', 'paypal', '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(13, '6828418f9eb34', 1, 'completed', 100, 198, 'USD', 0, NULL, NULL, '7KS023553H131011E', 'paypal', '2025-05-17 04:58:07', '2025-05-17 04:58:07'),
	(14, '682841bf688f4', 1, 'completed', 100, 198, 'USD', 0, NULL, NULL, '3P813872F6742043P', 'paypal', '2025-05-17 04:58:55', '2025-05-17 04:58:55'),
	(15, '682842e0e3a21', 1, 'completed', 100, 198, 'USD', 0, NULL, NULL, '2WC4320207313244A', 'paypal', '2025-05-17 05:03:44', '2025-05-17 05:03:44'),
	(16, '682843801a9c2', 1, 'completed', 100, 198, 'USD', 0, NULL, NULL, '55A63422S0318300A', 'paypal', '2025-05-17 05:06:24', '2025-05-17 05:06:24'),
	(17, '682843ea185e7', 1, 'completed', 200, 396, 'USD', 0, NULL, NULL, '88H148941S697851D', 'paypal', '2025-05-17 05:08:10', '2025-05-17 05:08:10'),
	(18, '68284505c6e63', 1, 'completed', 20, 39.6, 'USD', 0, NULL, NULL, '8M828920T0731082E', 'paypal', '2025-05-17 05:12:53', '2025-05-17 05:12:53');

-- Dumping data for table edu_core.order_items: ~26 rows (approximately)
INSERT IGNORE INTO `order_items` (`id`, `order_id`, `course_id`, `qty`, `price`, `commission_rate`, `item_type`, `quantity`, `created_at`, `updated_at`) VALUES
	(1, 3, 88, 1, 59, NULL, 'course', 1, '2025-05-13 07:53:20', '2025-05-13 07:53:20'),
	(2, 3, 6, 1, 19, NULL, 'course', 1, '2025-05-13 07:53:20', '2025-05-13 07:53:20'),
	(3, 3, 168, 1, 149, NULL, 'course', 1, '2025-05-13 07:53:20', '2025-05-13 07:53:20'),
	(4, 4, 88, 1, 59, NULL, 'course', 1, '2025-05-13 09:41:30', '2025-05-13 09:41:30'),
	(5, 5, 88, 1, 59, NULL, 'course', 1, '2025-05-13 09:44:23', '2025-05-13 09:44:23'),
	(6, 5, 6, 1, 19, NULL, 'course', 1, '2025-05-13 09:44:23', '2025-05-13 09:44:23'),
	(7, 5, 168, 1, 149, NULL, 'course', 1, '2025-05-13 09:44:23', '2025-05-13 09:44:23'),
	(8, 7, 88, 1, 59, NULL, 'course', 1, '2025-05-13 10:15:35', '2025-05-13 10:15:35'),
	(9, 8, 88, 1, 59, NULL, 'course', 1, '2025-05-13 10:19:42', '2025-05-13 10:19:42'),
	(10, 8, 168, 1, 149, NULL, 'course', 1, '2025-05-13 10:19:42', '2025-05-13 10:19:42'),
	(11, 9, 6, 1, 19, NULL, 'course', 1, '2025-05-13 10:21:18', '2025-05-13 10:21:18'),
	(12, 9, 88, 1, 59, NULL, 'course', 1, '2025-05-13 10:21:18', '2025-05-13 10:21:18'),
	(13, 10, 168, 1, 149, NULL, 'course', 1, '2025-05-14 05:32:21', '2025-05-14 05:32:21'),
	(14, 10, 170, 1, 59, NULL, 'course', 1, '2025-05-14 05:32:21', '2025-05-14 05:32:21'),
	(15, 11, 29, 1, 249, NULL, 'course', 1, '2025-05-14 10:31:52', '2025-05-14 10:31:52'),
	(16, 12, 150, 1, 249, 70, 'course', 1, '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(17, 12, 240, 1, 149, 70, 'course', 1, '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(18, 12, 88, 1, 59, 70, 'course', 1, '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(19, 12, 288, 1, 99, 70, 'course', 1, '2025-05-17 04:56:45', '2025-05-17 04:56:45'),
	(20, 13, 240, 1, 149, 70, 'course', 1, '2025-05-17 04:58:07', '2025-05-17 04:58:07'),
	(21, 14, 168, 1, 149, 70, 'course', 1, '2025-05-17 04:58:55', '2025-05-17 04:58:55'),
	(22, 15, 168, 1, 149, 70, 'course', 1, '2025-05-17 05:03:44', '2025-05-17 05:03:44'),
	(23, 16, 168, 1, 149, 70, 'course', 1, '2025-05-17 05:06:24', '2025-05-17 05:06:24'),
	(24, 17, 168, 1, 149, 70, 'course', 1, '2025-05-17 05:08:10', '2025-05-17 05:08:10'),
	(25, 17, 240, 1, 149, 70, 'course', 1, '2025-05-17 05:08:10', '2025-05-17 05:08:10'),
	(26, 18, 29, 1, 20, 70, 'course', 1, '2025-05-17 05:12:53', '2025-05-17 05:12:53');

-- Dumping data for table edu_core.password_reset_tokens: ~0 rows (approximately)

-- Dumping data for table edu_core.payment_settings: ~21 rows (approximately)
INSERT IGNORE INTO `payment_settings` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
	(1, 'paypal_mode', 'sandbox', '2025-05-13 12:08:23', '2025-05-14 05:18:12'),
	(2, 'paypal_currency', 'USD', '2025-05-13 12:08:23', '2025-05-14 05:41:52'),
	(3, 'paypal_rate', '1.98', '2025-05-13 12:08:23', '2025-05-14 05:16:38'),
	(4, 'paypal_client_id', 'AcESFdRsxnGi2bKzeOC64J1xnGsOH0ooeGeOoJU3K9mIaf59JzuauN3UBj6foHOgLx74r8m9LcsDnGlh', '2025-05-13 12:08:23', '2025-05-14 05:18:04'),
	(5, 'paypal_client_secret', 'ECCLcmBj43HfqRnCuQ5ClyaaYzJ5dX9eg7W5L3UpbSq-iKRH-n0dTNA4FWqA7rd4tuhrlL_ey2NH92-C', '2025-05-13 12:08:23', '2025-05-14 05:18:05'),
	(6, 'paypal_app_id', 'App_id', '2025-05-13 12:08:23', '2025-05-14 05:18:05'),
	(7, 'stripe_status', 'inactive', '2025-05-14 06:50:46', '2025-05-14 09:51:34'),
	(8, 'stripe_currency', 'USD', '2025-05-14 06:50:46', '2025-05-14 10:10:33'),
	(9, 'stripe_rate', '1', '2025-05-14 06:50:46', '2025-05-15 06:20:30'),
	(10, 'stripe_publishable_key', 'pk_test_51ROdu8PnNwEk6GXo4UweaSUDYxlY3qsASnJ72nSjS57YwGEzChvzLZSdZhi24TH6mD6P3wpOtLDoRlM0SvpebrG900AgqELUYd', '2025-05-14 06:50:46', '2025-05-14 09:51:25'),
	(11, 'stripe_secret', 'sk_test_51ROdu8PnNwEk6GXou6Nq0sBNK9Ad3YiRP2Dg2qE5q0HJ1sYzIW2Q90LTqxyZyujqnv5L4xtRSff7eCJDXuCTdE5b00OFGBzWVf', '2025-05-14 06:50:46', '2025-05-14 09:51:25'),
	(12, 'razorpay_status', 'active', '2025-05-15 06:18:09', '2025-05-15 06:18:09'),
	(13, 'razorpay_currency', 'INR', '2025-05-15 06:18:09', '2025-05-15 07:24:09'),
	(14, 'razorpay_rate', '84', '2025-05-15 06:18:09', '2025-05-15 06:18:09'),
	(15, 'razorpay_key', 'rzp_test_cvrsy43xvBZfDT', '2025-05-15 06:18:09', '2025-05-15 07:03:12'),
	(16, 'razorpay_secret', 'c9Aml4C5vOfSWmZehhlns5df', '2025-05-15 06:18:09', '2025-05-15 09:14:59'),
	(17, 'nordea_status', 'inactive', '2025-05-15 07:01:41', '2025-05-15 07:06:45'),
	(18, 'nordea_currency', 'AED', '2025-05-15 07:01:41', '2025-05-15 07:01:41'),
	(19, 'nordea_rate', '1', '2025-05-15 07:01:41', '2025-05-15 07:01:41'),
	(22, 'nordea_client_id', '06edbdd1a1b4de14dacf3d3144adc591', '2025-05-15 07:10:05', '2025-05-15 07:10:05'),
	(23, 'nordea_client_secret', '367317d71ff8577866595c16ce530ed1', '2025-05-15 07:10:05', '2025-05-15 07:10:05');

-- Dumping data for table edu_core.payout_gateways: ~4 rows (approximately)
INSERT IGNORE INTO `payout_gateways` (`id`, `gateway_name`, `status`, `hint`, `created_at`, `updated_at`) VALUES
	(17, 'PayPal', 1, 'Holder Name\r\nPaypal Id\r\nEmail Address', '2025-05-17 07:23:28', '2025-05-17 08:08:07'),
	(18, 'Stripe', 1, NULL, '2025-05-17 07:24:47', '2025-05-17 07:24:47'),
	(19, 'Razorpay', 1, NULL, '2025-05-17 07:24:54', '2025-05-17 07:24:54'),
	(20, 'Nordea', 0, NULL, '2025-05-17 07:25:05', '2025-05-17 07:25:05');

-- Dumping data for table edu_core.sessions: ~1 rows (approximately)
INSERT IGNORE INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
	('nSbUxY85jJCkht3axAywNdNJTWqZVfVjLrEn0AYm', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiU01JOXQ0M1dhekRQeTJaOXlxY3NGS1FObDY1SFY5MXBwcnRoTlF0aiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czoxODoiZmxhc2hlcjo6ZW52ZWxvcGVzIjthOjA6e31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo0NzoiaHR0cHM6Ly9lZHUtY29yZS50ZXN0L2FkbWluL2NlcnRpZmljYXRlLWJ1aWxkZXIiO31zOjUyOiJsb2dpbl9hZG1pbl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1747846127);

-- Dumping data for table edu_core.settings: ~6 rows (approximately)
INSERT IGNORE INTO `settings` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
	(1, 'site_title', 'Edu-Core', '2025-05-16 10:49:25', '2025-05-16 11:26:51'),
	(2, 'phone', '+1 (921) 537-1183', '2025-05-16 10:49:25', '2025-05-16 10:51:50'),
	(3, 'location', 'Pennsylvania, US', '2025-05-16 10:49:25', '2025-05-16 11:26:51'),
	(4, 'currency', 'USD', '2025-05-16 10:50:36', '2025-05-16 11:26:51'),
	(5, 'currency_icon', '$', '2025-05-16 10:50:36', '2025-05-16 11:26:51'),
	(6, 'commission_rate', '70', '2025-05-17 04:16:15', '2025-05-17 04:47:54');

-- Dumping data for table edu_core.users: ~3 rows (approximately)
INSERT IGNORE INTO `users` (`id`, `image`, `role`, `name`, `email`, `email_verified_at`, `password`, `headline`, `bio`, `gender`, `document`, `facebook`, `x`, `linkedin`, `github`, `website`, `wallet`, `login_as`, `approve_status`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, '/default_files/avatar.png', 'student', 'John Doe', 'john_doe@gmail.com', NULL, '$2y$12$51mqESmlhCH.PaTqrUo2a.vqeFxbYpeix2CNUTcQ002cqdeoTz95.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', NULL, NULL, NULL),
	(2, '/default_files/avatar.png', 'instructor', 'Opettaja', 'instructor@gmail.com', NULL, '$2y$12$gex2ZfmgI9n/8mvoBVIqf.31NaP/SBp2IRMUn229rmrJ1Plkn9ORy', NULL, 'Jokin testibioteksti tälle opettajalle', NULL, NULL, 'facebook', 'x', 'linkkari', 'github', 'website', 124, NULL, 'pending', NULL, NULL, '2025-05-18 10:18:32'),
	(3, '/default_files/avatar.png', 'instructor', 'Michael Scott', 'michael.scott@testing.com', NULL, '$2y$12$xS4NqqM0C.XgYsQLlEk8Cev3ghdTuFquGrjFg/F/xDTcNYP7kz2Em', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved', NULL, NULL, '2025-05-02 11:32:40');

-- Dumping data for table edu_core.watch_histories: ~10 rows (approximately)
INSERT IGNORE INTO `watch_histories` (`id`, `user_id`, `course_id`, `chapter_id`, `lesson_id`, `is_completed`, `created_at`, `updated_at`) VALUES
	(1, 1, 6, 9, 5, 1, '2025-05-20 14:03:00', '2025-05-21 07:19:53'),
	(2, 1, 6, 13, 14, 0, '2025-05-20 14:04:45', '2025-05-20 14:04:45'),
	(3, 1, 6, 9, 6, 1, '2025-05-20 14:04:48', '2025-05-21 07:19:41'),
	(4, 1, 6, 10, 11, 1, '2025-05-20 14:59:30', '2025-05-21 05:54:49'),
	(5, 1, 6, 9, 8, 0, '2025-05-21 05:02:51', '2025-05-21 09:11:45'),
	(6, 1, 6, 14, 17, 1, '2025-05-21 05:03:27', '2025-05-21 06:36:24'),
	(7, 1, 6, 9, 7, 1, '2025-05-21 05:12:44', '2025-05-21 08:25:38'),
	(8, 1, 6, 10, 10, 1, '2025-05-21 05:47:24', '2025-05-21 05:58:43'),
	(9, 1, 6, 15, 22, 0, '2025-05-21 07:20:18', '2025-05-21 07:20:18'),
	(10, 1, 6, 15, 21, 0, '2025-05-21 07:20:20', '2025-05-21 08:25:21');

-- Dumping data for table edu_core.withdrawals: ~1 rows (approximately)
INSERT IGNORE INTO `withdrawals` (`id`, `instructor_id`, `amount`, `transaction_id`, `status`, `created_at`, `updated_at`) VALUES
	(1, 2, 100, NULL, 'approved', '2025-05-18 06:45:20', '2025-05-18 10:18:32');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
